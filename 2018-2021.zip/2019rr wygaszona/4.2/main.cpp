#include <iostream>
#include <fstream>

int silnie[] = {1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880};

bool czySumaSilniCyfrRownaLiczbie(int n) {
    int kopia = n;
    int suma = 0;

    while (kopia > 0) {
        int cyfra = kopia % 10;
        suma += silnie[cyfra];
        kopia /= 10;
    }

    return suma == n;
}

int main() {
    std::ifstream wejscie("liczby.txt");
    int liczba;
    while (wejscie >> liczba) {
        if (czySumaSilniCyfrRownaLiczbie(liczba)) {
            std::cout << liczba << std::endl;
        }
    }
    return 0;
}