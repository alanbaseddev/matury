#include <iostream>
#include <fstream>


bool czyPotegaTrzy(int n) {
    if (n < 1) return false;
    while (n % 3 == 0) {
        n /= 3;
    }
    return n == 1;
}

int main() {
    std::ifstream infile("liczby.txt");
    int liczba;
    int licznik = 0;

    while (infile >> liczba) {
        if (czyPotegaTrzy(liczba)) {
            licznik++;
        }
    }
    std::cout << licznik << std::endl;
    return 0;
}