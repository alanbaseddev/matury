#include <iostream>
#include <vector>
#include <fstream>

int nwd(int a, int b) {
    while (b != 0) {
        const int pom = b;
        b = a % b;
        a = pom;
    }
    return a;
}

int main() {
    std::ifstream infile("liczby.txt");
    std::vector<int> liczby;
    int liczba;
    while (infile >> liczba) {
        liczby.push_back(liczba);
    }
    int max_dlugosc = 0;
    int najlepszy_start = 0;
    int najlepszy_dzielnik = 0;

    for (int i = 0; i < liczby.size(); i++) {
        int aktualny_nwd = liczby[i];

        for (int j = i + 1; j < liczby.size(); j++) {
            aktualny_nwd = nwd(aktualny_nwd, liczby[j]);

            if (aktualny_nwd == 1) break;

            if (int aktualna_dlugosc = j - i + 1; aktualna_dlugosc > max_dlugosc) {
                max_dlugosc = aktualna_dlugosc;
                najlepszy_start = liczby[i];
                najlepszy_dzielnik = aktualny_nwd;
            }
        }
    }
    std::cout << "Pierwsza liczba: " << najlepszy_start << std::endl;
    std::cout << "Dlugosc ciagu: " << max_dlugosc << std::endl;
    std::cout << "Wspolny dzielnik: " << najlepszy_dzielnik << std::endl;
    return 0;
}