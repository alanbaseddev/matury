#include <iostream>
#include <fstream>
#include <string>

int main() {
    std::ifstream infile("pary.txt");
    int liczba;
    std::string slowo;

    int min_liczba = -1;
    std::string min_slowo = "";
    bool znaleziono_pierwsza = false;

    while (infile >> liczba >> slowo) {
        if (liczba == static_cast<int>(slowo.length())) {

            if (!znaleziono_pierwsza ||
                liczba < min_liczba ||
                (liczba == min_liczba && slowo < min_slowo))
            {
                min_liczba = liczba;
                min_slowo = slowo;
                znaleziono_pierwsza = true;
            }
        }
    }
    if (znaleziono_pierwsza) {
        std::cout << min_liczba << " " << min_slowo << std::endl;
    }

    return 0;
}