#include <iostream>
#include <fstream>
#include <string>
#include <vector>

bool czyPierwsza(int n) {
    if (n < 2) return false;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return false;
    }
    return true;
}

int main() {
    std::ifstream infile("pary.txt");
    int liczba;
    std::string slowo;
    while (infile >> liczba >> slowo) {
        if (liczba % 2 == 0) {
            for (int p1 = 3; p1 <= liczba / 2; p1++) {
                int p2 = liczba - p1;
                if (czyPierwsza(p1) && czyPierwsza(p2)) {
                    std::cout << liczba << " " << p1 << " " << p2 << std::endl;
                    break;
                }
            }
        }
    }
    return 0;
}