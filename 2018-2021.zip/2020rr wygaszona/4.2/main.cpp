#include <iostream>
#include <fstream>
#include <string>


void rozwiazSlowo(std::string s) {
    if (s.empty()) return;
    std::string max_fragment = "";
    int max_dlugosc = 0;
    std::string aktualny_fragment = "";
    aktualny_fragment += s[0]; 
    int aktualna_dlugosc = 1;

    for (size_t i = 1; i <= s.length(); i++) {
        if (i < s.length() && s[i] == s[i - 1]) {
            aktualny_fragment += s[i];
            aktualna_dlugosc++;
        }
        else {
            if (aktualna_dlugosc > max_dlugosc) {
                max_dlugosc = aktualna_dlugosc;
                max_fragment = aktualny_fragment;
            }
            if (i < s.length()) {
                aktualny_fragment = s[i];
                aktualna_dlugosc = 1;
            }
        }
    }
    std::cout << max_fragment << " " << max_dlugosc << std::endl;
}

int main() {
    std::ifstream infile("pary.txt");
    int liczba;
    std::string slowo;
    while (infile >> liczba >> slowo) {
        rozwiazSlowo(slowo);
    }

    return 0;
}