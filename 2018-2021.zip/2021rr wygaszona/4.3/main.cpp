#include <iostream>
#include <fstream>
#include <string>
#include <vector>

int main() {
    std::ifstream infile("instrukcje.txt");
    std::string polecenie;
    char znak;

    int liczniki[26] = {0};

    while (infile >> polecenie >> znak) {
        if (polecenie == "DOPISZ") {
            int indeks = znak - 'A';
            liczniki[indeks]++;
        }
    }
    char najczestsza_litera;
    int max_wystapien = 0;

    for (int i = 0; i < 26; i++) {
        if (liczniki[i] > max_wystapien) {
            max_wystapien = liczniki[i];
            najczestsza_litera = static_cast<char>(i + 'A');
        }
    }

    std::cout << "Najczesciej dopisywana litera: " << najczestsza_litera << std::endl;
    std::cout << "Liczba dopisan: " << max_wystapien << std::endl;

    return 0;
}