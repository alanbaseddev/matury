#include <iostream>
#include <fstream>
#include <string>


int main() {
    std::ifstream plik("instrukcje.txt");
    std::string polecenie;
    char znak;
    std::string napis = "";

    while (plik >> polecenie >> znak) {
        switch (polecenie[0]) {
            case 'D':
                napis += znak;
                break;

            case 'Z':
                if (!napis.empty()) {
                    napis.back() = znak;
                }
                break;

            case 'U':
                if (!napis.empty()) {
                    napis.pop_back();
                }
                break;

            case 'P': {
                size_t pozycja = napis.find(znak);
                if (pozycja != std::string::npos) {
                    if (napis[pozycja] == 'Z') {
                        napis[pozycja] = 'A';
                    } else {
                        napis[pozycja]++;
                    }
                }
                break;
            }

            default:
                break;
        }
    }

    std::cout << "Finalny napis:" << std::endl;
    std::cout << napis << std::endl;
    return 0;
}