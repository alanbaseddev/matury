#include <iostream>
#include <fstream>

int main() {
    std::ifstream infile("instrukcje.txt");
    std::string polecenie;
    char znak;
    std::string aktualne_polecenie = "";
    int aktualna_dlugosc = 0;
    std::string najlepsze_polecenie = "";
    int max_dlugosc = 0;

    while (infile >> polecenie >> znak) {
        if (polecenie == aktualne_polecenie) {
            aktualna_dlugosc++;
        }
        else {
            aktualne_polecenie = polecenie;
            aktualna_dlugosc = 1;
        }

        if (aktualna_dlugosc > max_dlugosc) {
            max_dlugosc = aktualna_dlugosc;
            najlepsze_polecenie = polecenie;
        }
    }

    std::cout << "Najdluzszy ciag instrukcji: " << najlepsze_polecenie << std::endl;
    std::cout << "Dlugosc tego ciagu: " << max_dlugosc << std::endl;
    return 0;
}