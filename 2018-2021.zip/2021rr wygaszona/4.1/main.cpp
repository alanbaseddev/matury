#include <iostream>
#include <fstream>
#include <string>


int main() {
    std::ifstream infile("instrukcje.txt");
    std::string polecenie;
    char znak;
    std::string napis = "";

    while (infile >> polecenie >> znak) {
        switch (polecenie[0]) {
            case 'D':
                napis += znak;
                break;

            case 'Z':
                if (!napis.empty()) {
                    napis.back() = znak;
                }
                break;

            case 'U':
                if (!napis.empty()) {
                    napis.pop_back();
                }
                break;

            case 'P': {
                size_t pozycja = napis.find(znak);
                if (pozycja != std::string::npos) {
                    if (napis[pozycja] == 'Z') {
                        napis[pozycja] = 'A';
                    } else {
                        napis[pozycja]++;
                    }
                }
                break;
            }
        }
    }
    std::cout << "Calkowita dlugosc napisu po wykonaniu instrukcji: " << napis.length() << std::endl;
    return 0;
}