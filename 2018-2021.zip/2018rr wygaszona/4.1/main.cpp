#include <iostream>
#include <fstream>
#include <string>


int main() {
    std::ifstream infile("sygnaly.txt");
    std::string slowo;
    std::string przeslanie = "";
    int licznik_slow = 1;
    while (infile >> slowo) {
        if (licznik_slow % 40 == 0) {
            if (slowo.length() >= 10) {
                przeslanie += slowo[9];
            }
        }
        licznik_slow++;
    }
    std::cout << "Odczytane przeslanie: " << przeslanie << std::endl;
    return 0;
}