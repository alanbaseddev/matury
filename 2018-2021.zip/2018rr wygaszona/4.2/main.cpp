#include <iostream>
#include <fstream>
#include <string>
#include <vector>


int liczRozneLitery(std::string s) {
    bool wystapila[26] = {false};
    int licznik = 0;

    for (char c : s) {
        int indeks = c - 'A';
        if (!wystapila[indeks]) {
            wystapila[indeks] = true;
            licznik++;
        }
    }
    return licznik;
}

int main() {
    std::ifstream infile("sygnaly.txt");
    std::string slowo;
    std::string najlepsze_slowo = "";
    int max_roznych = 0;

    while (infile >> slowo) {
        int aktualne_rozne = liczRozneLitery(slowo);
        if (aktualne_rozne > max_roznych) {
            max_roznych = aktualne_rozne;
            najlepsze_slowo = slowo;
        }
    }
    std::cout << najlepsze_slowo << " " << max_roznych << std::endl;
    return 0;
}