#include <iostream>
#include <fstream>
#include <string>

using namespace std;

bool czyOdlegloscOk(const string &s) {
    if (s.empty()) return false;
    char min_litera = s[0];
    char max_litera = s[0];
    for (const char c : s) {
        if (c < min_litera) min_litera = c;
        if (c > max_litera) max_litera = c;
    }
    return max_litera - min_litera <= 10;
}

int main() {
    ifstream infile("sygnaly.txt");
    string slowo;
    while (infile >> slowo) {
        if (czyOdlegloscOk(slowo)) {
            cout << slowo << endl;
        }
    }
    return 0;
}